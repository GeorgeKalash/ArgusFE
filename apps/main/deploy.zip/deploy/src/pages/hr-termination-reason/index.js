// AUTO-GENERATED WRAPPER – uses code from @argus/module-hr/src/pages/hr-termination-reason
export { default } from '@argus/module-hr/src/pages/hr-termination-reason';
