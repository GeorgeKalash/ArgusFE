// AUTO-GENERATED WRAPPER – uses code from @argus/module-inventory/src/pages/iv-materials-tfr
export { default } from '@argus/module-inventory/src/pages/iv-materials-tfr';
