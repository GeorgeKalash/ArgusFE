// AUTO-GENERATED WRAPPER – uses code from @argus/module-manufacturing/src/pages/mf-gen-prod-order
export { default } from '@argus/module-manufacturing/src/pages/mf-gen-prod-order';
