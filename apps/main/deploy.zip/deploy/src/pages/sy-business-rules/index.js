// AUTO-GENERATED WRAPPER – uses code from @argus/module-system/src/pages/sy-business-rules
export { default } from '@argus/module-system/src/pages/sy-business-rules';
