// AUTO-GENERATED WRAPPER – uses code from @argus/module-financials/src/pages/fi-doc-aging
export { default } from '@argus/module-financials/src/pages/fi-doc-aging';
