// AUTO-GENERATED WRAPPER – uses code from @argus/module-hr/src/pages/hr-employee-list
export { default } from '@argus/module-hr/src/pages/hr-employee-list'
