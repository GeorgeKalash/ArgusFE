// AUTO-GENERATED WRAPPER – uses code from @argus/module-hr/src/pages/hr-certificate-lvl
export { default } from '@argus/module-hr/src/pages/hr-certificate-lvl';
