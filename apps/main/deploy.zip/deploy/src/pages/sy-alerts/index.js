// AUTO-GENERATED WRAPPER – uses code from @argus/module-system/src/pages/sy-alerts
export { default } from '@argus/module-system/src/pages/sy-alerts';
