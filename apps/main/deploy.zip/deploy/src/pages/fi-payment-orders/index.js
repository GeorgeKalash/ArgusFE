// AUTO-GENERATED WRAPPER – uses code from @argus/module-financials/src/pages/fi-payment-orders
export { default } from '@argus/module-financials/src/pages/fi-payment-orders';
