// AUTO-GENERATED WRAPPER – uses code from @argus/module-inventory/src/pages/iv-barcodes
export { default } from '@argus/module-inventory/src/pages/iv-barcodes';
