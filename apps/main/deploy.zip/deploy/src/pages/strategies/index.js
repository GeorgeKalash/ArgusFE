// AUTO-GENERATED WRAPPER – uses code from @argus/module-auth/src/pages/strategies
export { default } from '@argus/module-auth/src/pages/strategies';
