// AUTO-GENERATED WRAPPER – uses code from @argus/module-auth/src/pages/user-dashboard
export { default } from '@argus/module-auth/src/pages/user-dashboard';
