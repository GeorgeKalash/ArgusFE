// AUTO-GENERATED WRAPPER – uses code from @argus/module-financials/src/pages/fi-cash-tfr
export { default } from '@argus/module-financials/src/pages/fi-cash-tfr';
