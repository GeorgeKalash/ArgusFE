// AUTO-GENERATED WRAPPER – uses code from @argus/module-inventory/src/pages/iv-catalogue
export { default } from '@argus/module-inventory/src/pages/iv-catalogue';
