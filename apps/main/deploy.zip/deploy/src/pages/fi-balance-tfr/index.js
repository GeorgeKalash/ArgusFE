// AUTO-GENERATED WRAPPER – uses code from @argus/module-financials/src/pages/fi-balance-tfr
export { default } from '@argus/module-financials/src/pages/fi-balance-tfr'
