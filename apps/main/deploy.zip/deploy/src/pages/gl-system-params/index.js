// AUTO-GENERATED WRAPPER – uses code from @argus/module-financials/src/pages/gl-system-params
export { default } from '@argus/module-financials/src/pages/gl-system-params';
