// AUTO-GENERATED WRAPPER – uses code from @argus/module-financials/src/pages/description-template
export { default } from '@argus/module-financials/src/pages/description-template';
