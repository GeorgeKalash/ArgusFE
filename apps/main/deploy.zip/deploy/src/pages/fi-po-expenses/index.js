// AUTO-GENERATED WRAPPER – uses code from @argus/module-financials/src/pages/fi-po-expenses
export { default } from '@argus/module-financials/src/pages/fi-po-expenses';
