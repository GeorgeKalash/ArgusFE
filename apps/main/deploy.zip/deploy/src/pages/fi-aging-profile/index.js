// AUTO-GENERATED WRAPPER – uses code from @argus/module-financials/src/pages/fi-aging-profile
export { default } from '@argus/module-financials/src/pages/fi-aging-profile';
