// AUTO-GENERATED WRAPPER – uses code from @argus/module-manufacturing/src/pages/pm-task
export { default } from '@argus/module-manufacturing/src/pages/pm-task';
