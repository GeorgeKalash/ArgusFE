// AUTO-GENERATED WRAPPER – uses code from @argus/module-inventory/src/pages/iv-item-replacement
export { default } from '@argus/module-inventory/src/pages/iv-item-replacement';
