// AUTO-GENERATED WRAPPER – uses code from @argus/module-financials/src/pages/fi-dimensions
export { default } from '@argus/module-financials/src/pages/fi-dimensions';
