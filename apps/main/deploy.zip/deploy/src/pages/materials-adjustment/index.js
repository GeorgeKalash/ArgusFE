// AUTO-GENERATED WRAPPER – uses code from @argus/module-inventory/src/pages/materials-adjustment
export { default } from '@argus/module-inventory/src/pages/materials-adjustment';
