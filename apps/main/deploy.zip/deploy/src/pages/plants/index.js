// AUTO-GENERATED WRAPPER – uses code from @argus/module-system/src/pages/plants
export { default } from '@argus/module-system/src/pages/plants';
